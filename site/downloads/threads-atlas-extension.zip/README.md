# 話題星圖 Chrome 插件 0.2.0

線上網站：https://diffusework-wq.github.io/threads-atlas/

下載網站上的 ZIP，解壓縮後在 chrome://extensions 開啟開發人員模式，載入含 manifest.json 的資料夾。更新既有插件時，將來源檔覆蓋到原資料夾，按重新載入，再重新整理 Threads 和星圖。保留同一插件可保留既有收藏；建議先匯出備份。

自動收錄預設關閉。開啟後點進貼文詳情會自動收錄；動態牆上的「☆ 存入星圖」可直接手動收藏。純滑動不保存，不批次下載留言；手動點選哪篇才保存哪篇。內容無法可靠辨識、含多篇引文的卡片會略過。

資料保存在你的 Chrome 插件 storage.local，不上傳 GitHub。指定星圖網站透過本機橋接在瀏覽器內讀取，使用同一 Chrome 個人檔案即可，不需網站帳號或 Meta Token。不讀取密碼、Cookie、私訊或未送出內容。最多1,000篇，每篇12,000字元，另受Chrome儲存配額限制。

允許網站精確限定為 https://diffusework-wq.github.io/threads-atlas/ 與其 index.html，以及 localhost:8765 / 127.0.0.1:8765 的根路徑和 index.html。同GitHub網域其他專案無法讀取收藏。Chrome 權限畫面可能顯示整個網域，程式另核對路徑。

插件可匯出JSON；網站匯入僅供頁面預覽。卸載插件會移除資料。貼文頁可復原最新收錄；網站刪除可從最近30筆刪除資料復原。

網站公開示範使用人工核對摘要；個人分類使用本機關鍵字。收錄並不表示喜歡或認同，也不能視為Threads全平台熱度。
